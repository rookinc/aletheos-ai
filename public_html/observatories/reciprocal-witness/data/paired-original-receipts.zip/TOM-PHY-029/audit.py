#!/usr/bin/env python3
"""Test a reciprocal sheet-sensitive receiver on the registered quaternionic cover."""

import argparse
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
D = 24_000
UNIT = Fraction(1, D)


def read(path):
    return json.loads(path.read_bytes())


def sources(folder):
    digest, path = (ROOT / "INPUTS.sha256").read_text().strip().split("  ", 1)
    payload = ROOT / path
    assert sha256(payload.read_bytes()).hexdigest() == digest
    with ZipFile(payload) as archive:
        archive.extractall(folder)
    parent = folder / "TOM-PHY-028"
    receipt = (parent / "receipt.json").read_bytes()
    output = folder / "replayed-028.json"
    subprocess.run([sys.executable, "-B", "audit.py", "--output", str(output)], cwd=parent, check=True)
    assert output.read_bytes() == receipt
    prior = runpy.run_path(str(parent / "audit.py"))
    a23, source, sites, captures, _, _ = prior["load"](folder)
    comparison = json.loads(receipt)
    cochains = prior["cover_data"](folder)
    return a23, prior, source, sites, captures, cochains, comparison, sha256(receipt).hexdigest()


def add(x, y, scale=1):
    z = x.copy()
    for k, value in y.items():
        z[k] = z.get(k, 0) + scale * value
    return {k: v for k, v in z.items() if v}


def dot(x, y):
    return sum(value * y.get(i, 0) for i, value in x.items())


def laplacian(adj, x):
    out = defaultdict(Fraction)
    for i, value in x.items():
        out[i] += len(adj[i]) * value
        for j in adj[i]:
            out[j] -= value
    return {i: v for i, v in out.items() if v}


def push(adj, x, u):
    velocity = add(u, laplacian(adj, x), -UNIT)
    return add(x, velocity), velocity


def pull(adj, x, u):
    previous = add(x, u, -1)
    return previous, add(u, laplacian(adj, previous), UNIT)


def energy(adj, x, u):
    return D * dot(u, u) + dot(x, laplacian(adj, add(x, u, -1)))


def lift_tape(tape, gauge, initial_sheets, cochain, index, projection, adj):
    def upstairs(point):
        return index[tuple(2 * gauge[v] + t for v, t in zip(point, sheet, strict=True))]

    sheet = list(initial_sheets)
    lifted = [upstairs(tape[0]["ordered_G60_point"])]
    for before, after in zip(tape, tape[1:]):
        start, end = (t["ordered_G60_point"] for t in (before, after))
        f, = (i for i in (0, 1) if start[i] != end[i])
        sheet[f] ^= tuple(sorted((gauge[start[f]], gauge[end[f]]))) in cochain
        lifted.append(upstairs(end))
        assert lifted[-1] in adj[lifted[-2]]
    assert [projection[u] for u in lifted] == [p["G1800_vertex"] for p in tape]
    return lifted


def match_registers(a23, source, sites, captures, compare):
    recorded = defaultdict(dict)
    records = {(tuple(h["record"])): (fork, h["checkpoint"])
               for fork, histories in sites.items() for h in histories}
    for cap in captures:
        observed = a23["verify"](cap, source)
        key = tuple(observed["record"])
        fork, check = records[key]
        first_tick = cap["observations"][-1]["tick"]
        first = tuple(observed["first_edge"])
        assert first[0] == fork and observed["checkpoint"] == check
        registered = cap["trace"][first_tick - 1:]
        assert len(registered) == 6 and first not in recorded[fork, check]
        recorded[fork, check][first] = observed["relative_branch"], registered
    assert len(recorded) == 8 and all(len(options) == 2 for options in recorded.values())
    controls = compare["independent_observed_edge_write_controls"]
    assert len(controls) == 32
    for c in controls:
        normal, forced = (tuple(c[k]["observed_first_edge"]) for k in ("normal", "forced_other_exit"))
        assert set(recorded[c["fork"], c["checkpoint"]]) == {normal, forced}
        assert recorded[c["fork"], c["checkpoint"]][normal][0] == ("swap" if c["fixed_echo"] else "preserve")
        assert recorded[c["fork"], c["checkpoint"]][forced][0] != recorded[c["fork"], c["checkpoint"]][normal][0]
    return recorded, controls


def check_cover_geometry(adj, deck, projection):
    for r, receivers in enumerate(adj):
        rr = deck[r]
        assert rr not in receivers and r not in receivers
        assert {deck[v] for v in receivers} == adj[rr]
        assert not receivers & adj[rr]
        assert len({projection[v] for v in receivers}) == 8
    return sum(map(len, adj))


def project_pair_sums(data, projection):
    out = defaultdict(Fraction)
    for i, v in data.items():
        out[projection[i]] += v
    return {k: v for k, v in out.items() if v}


def local_test(adj, deck, projection, r):
    zr = deck[r]
    receivers = sorted(adj[r])
    positive = []
    negative = []
    sums = []
    for q, sign in ((r, 1), (zr, -1)):
        x0 = {q: Fraction(1)}
        first = push(adj, x0, {})
        second = push(adj, *first)
        assert pull(adj, *first) == (x0, {}) and pull(adj, *second) == first
        assert all(energy(adj, *state) == 8 for state in ((x0, {}), first, second))
        x1, u1 = first
        receiver_contrasts = [u1.get(v, 0) - u1.get(deck[v], 0) for v in receivers]
        assert receiver_contrasts == [sign * UNIT] * 8

        # Cancel the receiver position's odd part while leaving its even part and velocity intact.
        clamped = x1.copy()
        for v in receivers:
            zv = deck[v]
            clamped[v] = clamped[zv] = (x1.get(v, 0) + x1.get(zv, 0)) / 2
        assert project_pair_sums(clamped, projection) == project_pair_sums(x1, projection)
        _, clamped_u2 = push(adj, clamped, u1)
        _, free_u2 = second
        return_delta = add(free_u2, clamped_u2, -1)
        on_source = return_delta.get(r, 0) - return_delta.get(zr, 0)
        assert on_source == sign * 8 * UNIT**2
        one_port_returns = []
        for v in receivers:
            # A single receiving pair suffices. This also tests the reverse coefficient of its native edge.
            w = deck[v]
            test = x1.copy()
            test[v] = test[w] = (x1.get(v, 0) + x1.get(w, 0)) / 2
            _, single_u2 = push(adj, test, u1)
            delta = add(free_u2, single_u2, -1)
            difference = delta.get(r, 0) - delta.get(zr, 0)
            assert difference == sign * UNIT**2
            one_port_returns.append(difference)
            _, reverse_u1 = push(adj, {v: Fraction(1)}, {})
            assert reverse_u1.get(r, 0) == UNIT and reverse_u1.get(zr, 0) == 0
        sums.append([project_pair_sums(vector, projection) for state in (first, second) for vector in state])
        row = {"launched_at": q, "signed_receiver_velocity_per_port": str(receiver_contrasts[0]),
               "signed_sum_receiver_velocity": str(sum(receiver_contrasts)),
               "source_odd_velocity_change_from_one_receiver_pair": str(one_port_returns[0]),
               "source_odd_velocity_change_from_all_receiver_pairs": str(on_source),
               "unforced_energy": 8}
        (positive if sign == 1 else negative).append(row)
    assert sums[0] == sums[1]
    return {"reference_endpoint": r, "other_sheet": zr, "base_endpoint": projection[r],
            "receiver_ports": receivers, "preserve": positive[0], "swap": negative[0]}


def replay(a23, prior, source, sites, captures, cochains, compare):
    records, controls = match_registers(a23, source, sites, captures, compare)
    _, _, _, _, a, _, _, _, _ = source
    states = {}
    cases = []
    geometry = 0
    for cover_sign in (-1, 1):
        cochain = cochains["Q8", cover_sign]
        index, projection, deck, adj = prior["product_cover"](source, cochain)
        geometry += check_cover_geometry(adj, deck, projection)
        for c in controls:
            normal, forced = (tuple(c[k]["observed_first_edge"]) for k in ("normal", "forced_other_exit"))
            options = records[c["fork"], c["checkpoint"]]
            preserve, = (step for step, (relation, _) in options.items() if relation == "preserve")
            for gauge in (tuple(range(60)), a):
                for sheet in product((0, 1), repeat=2):
                    relative = {}
                    for actual in (normal, forced):
                        relation, tape = options[actual]
                        lifted = lift_tape(tape, gauge, sheet, cochain, index, projection, adj)
                        relative[actual] = relation, lifted[0], lifted[-1]
                    assert relative[normal][1] == relative[forced][1]
                    assert deck[relative[normal][2]] == relative[forced][2]
                    ref = relative[preserve][2]
                    key = cover_sign, ref
                    if key not in states:
                        states[key] = local_test(adj, deck, projection, ref)
                    effects = {}
                    for label, actual in (("normal", normal), ("forced_other_exit", forced)):
                        relation, _, observed = relative[actual]
                        response = states[key][relation]
                        assert response["launched_at"] == observed
                        effects[label] = {"observed_exit": actual, "observed_endpoint": observed,
                                          "receiver_velocity": response["signed_sum_receiver_velocity"],
                                          "feedback": response["source_odd_velocity_change_from_all_receiver_pairs"]}
                    assert Fraction(effects["normal"]["receiver_velocity"]) == -Fraction(
                        effects["forced_other_exit"]["receiver_velocity"])
                    assert Fraction(effects["normal"]["feedback"]) == -Fraction(effects["forced_other_exit"]["feedback"])
                    cases.append({"cover_triangle_sign": cover_sign, "fork": c["fork"], "checkpoint": c["checkpoint"],
                                  "fixed_echo": c["fixed_echo"], "test": c["test"], "reference": c["reference"],
                                  "diagonal_a_representative": gauge == a, "start_sheet_labels": sheet,
                                  "same_reference_endpoint": ref, **effects})
    assert geometry == 57_600 and len(cases) == 512
    assert len(states) == 8
    return {"marked_receiver_states": [{"cover_triangle_sign": sign, **record}
                                        for (sign, _), record in sorted(states.items())],
            "matched_route_interventions": len(cases), "all_matched_controls": cases,
            "adjacency_contacts_checked_across_two_covers": geometry}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "receipt.json")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="tom-phy-029-") as temp:
        a23, prior, source, sites, captures, cochains, compare, parent_hash = sources(Path(temp))
        result = replay(a23, prior, source, sites, captures, cochains, compare)
    receipt = {"audit": "TOM-PHY-029", "upstream_028_receipt_sha256": parent_hash,
               "update_denominator": D, "laplacian": "8I-A on the quaternionic product cover",
               "reference": "calibrated preserve lift from the same incoming state and launch sheet",
               "field_preparation": "unit displacement at the actual lifted endpoint with zero velocity",
               "effect": result, "endogenous_product_cover_admission_or_pulse_encoder_derived": False,
               "later_registered_event_law_derived": False, "historical_W_TI_assignment": None}
    a23["write"](args.output, receipt)


if __name__ == "__main__":
    main()
