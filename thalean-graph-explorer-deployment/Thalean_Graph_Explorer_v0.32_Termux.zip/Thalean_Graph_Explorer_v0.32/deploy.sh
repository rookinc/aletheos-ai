#!/usr/bin/env bash
# Install the reviewed single-file release using the Aletheos SSH alias.
set -u

remote=gurtiamy
release_url=https://aletheos.ai/observatories/thalean-graph-explorer/
expected=5fce7238bb67e2263a9244623dec4f47a6b79e0e9fb323214a8fcff6dfc215c9

fail() {
  printf 'Explorer deployment stopped: %s\n' "$*" >&2
  exit 1
}

for tool in ssh curl sha256sum; do
  command -v "$tool" >/dev/null 2>&1 || fail "Missing $tool. In Termux, run pkg install openssh curl coreutils."
done
package_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || fail 'Cannot locate release folder.'
html=$package_dir/Advanced_Transport_Observer.html
local_hash=$(sha256sum -- "$html") || fail 'Cannot read release HTML.'
[ "${local_hash%% *}" = "$expected" ] || fail 'Local HTML differs from the reviewed v0.32 release.'

remote_install=$(cat <<'REMOTE'
set -u
expected=$1
previous=d0dc9e81a5a45096c2a1704d3d00816f9544e1de8dad8827d10729014ae16947
stop() {
  printf 'Aletheos server: %s\n' "$*" >&2
  exit 1
}
parent=$HOME/www/observatories
[ -d "$parent" ] && [ ! -L "$parent" ] || stop 'Existing www/observatories directory required.'
target=$parent/thalean-graph-explorer
[ ! -L "$target" ] || stop 'Explorer directory is a symlink.'
if [ ! -d "$target" ]; then
  mkdir -m 755 -- "$target" || stop 'Cannot create Explorer directory.'
fi
index=$target/index.html
stage=$(mktemp "$target/.explorer-upload.XXXXXXXX") || stop 'Cannot stage upload.'
trap 'rm -f -- "$stage"' EXIT
cat > "$stage" || stop 'Cannot receive upload.'
digest=$(sha256sum -- "$stage") || stop 'Cannot check upload checksum.'
[ "${digest%% *}" = "$expected" ] || stop 'Uploaded HTML checksum differs.'

if [ -e "$index" ] || [ -L "$index" ]; then
  [ -f "$index" ] && [ ! -L "$index" ] || stop 'Existing index is not a regular file.'
  digest=$(sha256sum -- "$index") || stop 'Cannot check existing page.'
  current=${digest%% *}
  if [ "$current" = "$expected" ]; then
    printf 'Explorer v0.32 is already installed.\n'
    exit 0
  fi
  [ "$current" = "$previous" ] || stop 'A different Explorer page already exists at this path.'
  backup_dir=$HOME/.thalean-graph-explorer-backups
  [ ! -L "$backup_dir" ] || stop 'Backup directory is a symlink.'
  mkdir -p -m 700 -- "$backup_dir" || stop 'Cannot create backup directory.'
  backup=$(mktemp "$backup_dir/v0.31.XXXXXXXX.html") || stop 'Cannot reserve backup.'
  cp -- "$index" "$backup" || stop 'Cannot back up v0.31.'
  digest=$(sha256sum -- "$backup") || stop 'Cannot verify backup.'
  [ "${digest%% *}" = "$previous" ] || stop 'Backup checksum differs.'
  chmod 644 "$stage" || stop 'Cannot set page permissions.'
  [ -f "$index" ] && [ ! -L "$index" ] || stop 'Existing page changed during install.'
  digest=$(sha256sum -- "$index") || stop 'Cannot recheck existing page.'
  [ "${digest%% *}" = "$previous" ] || stop 'Existing page changed during install.'
  mv -Tf -- "$stage" "$index" || stop 'Cannot replace the verified v0.31 page.'
  printf 'Explorer v0.32 installed. Rollback copy: %s\n' "$backup"
else
  chmod 644 "$stage" || stop 'Cannot set page permissions.'
  ln -T -- "$stage" "$index" || stop 'Could not publish index.html without replacing a file.'
  printf 'Explorer v0.32 installed at ~/www/observatories/thalean-graph-explorer/index.html.\n'
fi
REMOTE
) || fail 'Cannot prepare remote install command.'

# Quote the script for the SSH login shell and stream the HTML bytes to Bash.
quoted_install=${remote_install//\'/\'\\\'\'}
printf 'Uploading Explorer v0.32 via %s…\n' "$remote"
ssh -T "$remote" "bash -c '$quoted_install' bash '$expected'" < "$html" || fail 'SSH upload or installation failed. Check the server message above.'

served=$(mktemp) || fail 'File installed, but HTTP verification could not start.'
trap 'rm -f -- "$served"' EXIT
curl -fsSL --max-time 40 --retry 2 -o "$served" "${release_url}?release=v0.32" || fail "File installed, but the public URL could not be fetched: $release_url"
served_hash=$(sha256sum -- "$served") || fail 'File installed, but the HTTP response could not be hashed.'
[ "${served_hash%% *}" = "$expected" ] || fail "File installed, but the public response differs from v0.32: $release_url"
printf 'Live v0.32 verified: %s\n' "$release_url"
