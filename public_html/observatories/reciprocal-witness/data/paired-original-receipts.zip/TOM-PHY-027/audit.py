#!/usr/bin/env python3
"""Replay an exact TI echo comparator coupled to the registered Project 41 fork."""

import argparse
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
from uuid import NAMESPACE_URL, uuid5
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
TRIANGLE = (5, 11, 20, 5)
SIGN_VALUES = (1, -1)


def read(path):
    return json.loads(path.read_bytes())


def checked_input(folder, archive_name):
    expected, name = next(line.split("  ", 1) for line in (folder / "INPUTS.sha256").read_text().splitlines()
                          if line.endswith("/" + archive_name))
    archive = folder / name
    assert sha256(archive.read_bytes()).hexdigest() == expected
    return archive


def load(folder):
    upstream = ROOT
    for rev in (26, 25, 24):
        name = f"TOM-PHY-{rev:03}"
        with ZipFile(checked_input(upstream, f"{name}.zip")) as archive:
            archive.extractall(folder)
        upstream = folder / name
    audit24 = runpy.run_path(str(upstream / "audit.py"))
    audit23, source, _, limitation = audit24["load"](folder)
    sites, trials = audit24["make_trials"](audit23, source)
    sealed = read(upstream / "receipt.json")["trials"]
    assert audit23["encode"](trials) == audit23["encode"](sealed)
    prior = {i: read(folder / f"TOM-PHY-{i:03}/receipt.json") for i in (17, 18, 19)}
    tested = folder / "TOM-PHY-026/receipt.json"
    prior[26] = read(tested)
    return (audit24, audit23, source, sites, prior, limitation,
            sha256(tested.read_bytes()).hexdigest())


def echo_measurement(prior, edges):
    upstream = prior[18]
    paths = prior[17]["equal_length_interferometer"]["test_and_reference_route"]
    assert tuple(paths) == TRIANGLE
    assert all((a, b) in edges for a, b in zip(TRIANGLE, TRIANGLE[1:]))
    assert upstream["native_geometry"]["oriented_TI_edge"] == list(TRIANGLE[:2])
    covers = prior[17]["fully_symmetric_double_covers"]
    positive, = (c for c in covers if c["connected"] and c["deck_extension_over_G15"] == "Q8"
                 and c["triangle_sign"] == 1)
    split_negative, = (c for c in covers if c["connected"] and c["deck_extension_over_G15"] == "C2^3"
                       and c["triangle_sign"] == -1)
    assumed_delay = prior[19]["timing_register"]
    assert assumed_delay["delay_reference_cycle_signature"] == positive["cycle_signature"]
    assert assumed_delay["early_positive_reference_delay_hops"] == 3
    release = assumed_delay["common_release_tick"]
    assert release == 6
    coin = [[Fraction(v) for v in row] for row in upstream["local_scattering_census"]
            ["coin_selected_by_continuity_and_current_balance"]]
    assert coin == [[Fraction(1, 2) - int(i == j) for j in range(4)] for i in range(4)]
    source_cases = {(tuple(r["arm_signs"]), r["launch"]): r["weights_at_native_hops_0_3_6"]
                    for r in upstream["time_resolved_common_port_readout"]["exact_timing_cases"]}

    def scatter(a):
        return tuple(sum(c * v for c, v in zip(row, a, strict=True)) for row in coin)

    echoes = {}
    for s, r in product(SIGN_VALUES, repeat=2):
        incoming = (0, 0, 1, 1)
        wave = scatter(incoming)
        detected = {0: wave[2:]}
        for tick in (3, 6):
            wave = scatter((s * wave[0], r * wave[1], 0, 0))
            detected[tick] = wave[2:]
        assert wave[:2] == (0, 0)
        weights = [sum(v * v for v in detected[tick]) / 2 for tick in (0, 3, 6)]
        assert list(map(str, weights)) == source_cases[(s, r), "paired"]
        tick, = (hop for hop, pair in detected.items() if pair != (0, 0))
        amplitude, = set(detected[tick])
        assert amplitude == (s if s == r else -1) and sum(weights) == 1
        assert tick == (3 if s == r else 6)
        echoes[s, r] = {"detected_hop": tick, "arrival_mode_amplitude": int(amplitude),
                        "paired_launch_power_by_hop_0_3_6": list(map(str, weights)),
                        "extra_delay_hops": release - tick, "retained_bit": int(tick == release)}
    assert all(echo["retained_bit"] == int(s != r) for (s, r), echo in echoes.items())
    assert all(source_cases[signs, "first_port"][0] == "1/2" for signs in echoes)
    return echoes, release, {"positive_Q8": positive["cycle_signature"],
                              "negative_split_bipartite": split_negative["cycle_signature"]}


def keep_time_bit(echoes, release):
    transfers = {}
    for signs, echo in echoes.items():
        bit = echo["retained_bit"]
        # TOM-PHY-019's reversible time-mode swap with memory initialized to zero.
        new_time, memory = 0, bit
        old_time, old_memory = memory, new_time
        assert (old_time, old_memory) == (bit, 0)
        assert echo["detected_hop"] + echo["extra_delay_hops"] == release
        transfers[signs] = memory
    return transfers


def replay_forks(a24, a23, source, sites, prior, echoes, release, bits):
    provenance, pi, edges, aut, central_a, atlas, _, _, _ = source
    orbits, ids = atlas
    cases = {}
    covariance = 0
    for fork, histories in sorted(sites.items()):
        for h in histories:
            current, prev = h["position"], h["arrived_from"]
            exits = h["exits"]
            memory = h["retained_edge"]
            successors = {v: a23["take_step"](current, v, orbits, edges) for v in exits}
            local = {}
            for s, r in product(SIGN_VALUES, repeat=2):
                sensed_echo = echoes[s, r]
                aim = a24["AIMS"][bits[s, r]]
                next_id = a24["decide"](memory, aim, exits)
                occurrence = str(uuid5(NAMESPACE_URL, f"TOM-PHY-027/{h['record']}/{s}/{r}"))
                capture = a23["make_capture"](occurrence, provenance, h["options"][next_id], atlas, edges)
                check = a23["verify"](capture, source)
                assert check["first_edge"] == [fork, next_id] and check["relative_branch"] == aim
                trace = capture["trace"]
                first_tick = capture["observations"][-1]["tick"]
                # Rejoin the TOM-PHY-019 feeder at native vertex 5 after the echo.
                feeder_at_5 = trace[2]
                assert feeder_at_5["ordered_G60_point"] == trace[0]["ordered_G60_point"]
                first_tick_after_echo = release + first_tick - feeder_at_5["tick"]
                assert first_tick_after_echo == prior[19]["first_successor_common_clock_tick"] == 15
                local[s, r] = {"test_triangle_return": s, "reference_triangle_return": r,
                               "echo": sensed_echo, "aim": aim, "first_edge": check["first_edge"],
                               "first_successor_common_tick": first_tick_after_echo,
                               "continuation_end": trace[-1]["G1800_vertex"],
                               "capture_sha256": capture["content_sha256"]}
                cases[fork, h["checkpoint"], s, r] = local[s, r]
            assert len({(t["first_successor_common_tick"], t["continuation_end"]) for t in local.values()}) == 1

            for g in aut.values():
                assert all(g[central_a[v]] == central_a[g[v]] for v in (*current, *prev))

                def relabel(point):
                    return tuple(g[v] for v in point)

                end = relabel(current)
                _, new_memory = a23["signature"](pi, relabel(prev), end, edges)
                new_exits = {ids[relabel(p)]: a23["signature"](pi, end, relabel(p), edges)[1]
                             for p in successors.values()}
                for t in local.values():
                    moved = a24["decide"](new_memory, t["aim"], new_exits)
                    assert moved == ids[relabel(successors[t["first_edge"][1]])]
                    covariance += 1
    assert len(cases) == 32 and covariance == 15360

    swaps = defaultdict(int)
    for fork, histories in sites.items():
        for actual, alternate in (histories, histories[::-1]):
            checkpoint, mate = actual["checkpoint"], alternate["checkpoint"]
            for s, r in product(SIGN_VALUES, repeat=2):
                observed = cases[fork, checkpoint, s, r]["first_edge"]
                assert observed != cases[fork, checkpoint, s, -r]["first_edge"]
                assert observed != cases[fork, checkpoint, -s, r]["first_edge"]
                assert observed != cases[fork, mate, s, r]["first_edge"]
                assert observed == cases[fork, checkpoint, -s, -r]["first_edge"]
                swaps["flip_reference"] += 1
                swaps["flip_test"] += 1
                swaps["flip_history"] += 1
                swaps["flip_both_signs"] += 1
    assert set(swaps.values()) == {32}
    return cases, dict(swaps), covariance


def action_law_controls(cases, prior):
    # Encode agreement as group identity. A permutation of the two exits is
    # represented by its swap bit. The opposite phase mapping is not unital.
    candidates = list(product((0, 1), repeat=2))
    maps = [list(f) for f in candidates if all(f[g ^ h] == (f[g] ^ f[h]) for g, h in product((0, 1), repeat=2))]
    assert maps == [[0, 0], [0, 1]]
    pairs_without_reference = defaultdict(set)
    for (fork, history, test, _), trial in cases.items():
        pairs_without_reference[fork, history, test].add(tuple(trial["first_edge"]))
    assert len(pairs_without_reference) == 16 and {len(v) for v in pairs_without_reference.values()} == {2}
    table = prior["timing_scope_and_minimal_test"]["six_compatible_policy_predictions"]
    at_480 = {}
    exit_bits = {505: 0, 535: 1}
    for ref, name in ((1, "aim_at_timing_bits_0_1_01"), (-1, "aim_at_timing_bits_0_1_10")):
        outcomes = [cases[480, checkpoint, test, ref]["first_edge"][1]
                    for checkpoint, test in product((420, 540), SIGN_VALUES)]
        assert [exit_bits[v] for v in outcomes] == table[name]
        at_480[ref] = outcomes
    return {"compositional_swap_bit_maps": maps, "unique_faithful_map": [0, 1],
            "same_fork_history_test_sign_opposite_actions_under_reference_swap": len(pairs_without_reference),
            "fork_480_fixed_reference_predictions_match_both_026_polarities": at_480,
            "best_balanced_accuracy_for_controller_without_reference": "1/2"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "receipt.json")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="tom-phy-027-") as temp:
        a24, a23, source, sites, prior, limitation, upstream_sha = load(Path(temp))
        echoes, release, covers = echo_measurement(prior, source[2])
        bits = keep_time_bit(echoes, release)
        cases, contrasts, covariance = replay_forks(a24, a23, source, sites, prior, echoes, release, bits)
        checks = action_law_controls(cases, prior[26])
    receipt = {"audit": "TOM-PHY-027", "upstream_026_receipt_sha256": upstream_sha,
               "TI_triangle": TRIANGLE, "reference_cover_signatures": covers,
               "common_release_tick": release, "echo_controls": [
                   {"test": s, "reference": r, **echoes[s, r]} for s, r in product(SIGN_VALUES, repeat=2)],
               "controlled_fork_cases": [{"fork": key[0], "checkpoint": key[1], **trial}
                                         for key, trial in sorted(cases.items())],
               "native_relabeling_decisions": covariance, "directed_matched_contrasts": contrasts,
               "action_law_controls": checks, "selector_provenance_boundary": limitation,
               "echo_to_exit_wiring": "stipulated identity for agreement, transposition for disagreement",
               "wiring_derived_from_source": False, "historical_W_TI_assignment": None}
    a23["write"](args.output, receipt)


if __name__ == "__main__":
    main()
