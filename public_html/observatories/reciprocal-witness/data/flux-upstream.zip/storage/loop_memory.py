"""Write opposite native circulation, match the energy covariance, store and read."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

def run(chart, raw_tensor, normal_tensor, registered, actions, generator):
    with np.load(chart) as data:
        B=data['shared_hessians']
    with np.load(raw_tensor) as data:
        P=data['PC30']; incidence=data['B2']
    with np.load(normal_tensor) as data:
        lift=data['four_flux_basis']
    labels=np.asarray([r['axis_primitive'] for r in json.loads(registered.read_bytes())['registered_slots']])
    axes=labels@lift/np.sqrt(24)
    left,right=axes[[0,11]]
    g=.25;omega=np.sqrt(10.)
    mat=lambda f:np.einsum('r,rij->ij',f,B)
    src=lambda w:.5*np.einsum('i,rij,j->r',w,B,w)
    native_edges=incidence.T@incidence
    i,j=np.triu_indices(20,1); present=native_edges[i,j]!=0
    i,j=i[present],j[present];weights=-native_edges[i,j]
    assert len(i)==60 and np.all(weights==2)
    assert np.max(abs(native_edges@lift-10*lift))<1e-11
    def energy_cov(f,vel):return np.outer(f,f)+np.outer(vel,vel)/10
    def avg_energy(f,vel):
        R=lift@energy_cov(f,vel)@lift.T
        e=2.5*R.diagonal().copy()
        part=weights*(R[i,i]+R[j,j]-2*R[i,j])/8
        np.add.at(e,i,part);np.add.at(e,j,part)
        return e
    def instant_energy(f,vel):
        F=lift@f;V=lift@vel
        local=.5*V**2
        springs=weights*(F[i]-F[j])**2/4
        np.add.at(local,i,springs);np.add.at(local,j,springs)
        return local
    def loop(f,v):
        F=lift@f;V=lift@v
        return weights/2*(F[i]*V[j]-F[j]*V[i])
    def loop_div(current):
        dv=np.zeros(20);np.add.at(dv,i,current);np.add.at(dv,j,-current);return dv
    with np.load(actions) as az:
        vertices=az['vertex_target']; targets=az['face_target'];signs=az['face_sign']
    info=json.loads(generator.read_bytes());b=[info['relabeled_involution_b_current_labels'][str(x)] for x in range(60)]
    b=np.array(b);keep=np.all(vertices[:,b]==b[vertices],axis=1)
    mats=np.zeros((len(vertices),20,20),dtype=int)
    for k,(t,s) in enumerate(zip(targets,signs)):mats[k,t,np.arange(20)]=s
    d,e=labels[[0,11]]
    fix=np.flatnonzero(keep&np.all((mats@d)==d,axis=1)&np.all((mats@e)==e,axis=1))
    flip=np.flatnonzero(keep&np.all((mats@d)==d,axis=1)&np.all((mats@e)==-e,axis=1))
    sum_projector=np.sum(mats[fix],axis=0)@P
    # Integer equality with the exact orthogonal projection onto the two axes.
    assert np.array_equal(24*sum_projector,len(fix)*30*(np.outer(d,d)+np.outer(e,e))) and len(flip)>0
    u=np.linalg.eigh(mat(left))[1][:,-1]
    v=np.linalg.eigh(mat(right))[1]
    writer=[v[:,-1],v[:,0]]
    assert np.linalg.norm(src(writer[0])+src(writer[1]))<1e-13
    def derivative(t,z):
        x,y,f=z[:6],z[6:12],z[12:16]
        return np.r_[z[16:],-g*(mat(f)@x),-g*(mat(f)@y),-10*f-g*(src(x)+src(y))]
    def cross(z):
        f=z[12:16];p=z[28:]
        return (left@f)*(right@f)+(left@p)*(right@p)/10
    def solve(tol,step):
        hist=[]
        for w in writer:
            initial=np.r_[u,w,np.zeros(4),np.zeros(12),omega*left]
            sol=solve_ivp(derivative,(0,1.01),initial,rtol=tol,atol=tol/80,max_step=step,method='DOP853',dense_output=True)
            assert sol.success
            hist.append(sol)
        bracket=[.96,1.01]
        signs_bracket=[cross(hist[0].sol(t)) for t in bracket]
        assert signs_bracket[0]*signs_bracket[1]<0
        cut=brentq(lambda t:cross(hist[0].sol(t)),*bracket,xtol=5e-15)
        states=[s.sol(cut) for s in hist]
        f,vel=states[0][12:16],states[0][28:]
        # Same phase advance on both released records; right-axis field
        # vanishes and left-axis flux velocity vanishes at the chosen section.
        ang=float(np.arctan2(-(right@f),right@vel/omega) % (2*np.pi))
        if left@(f*np.cos(ang)+vel*np.sin(ang)/omega)<0:ang=(ang+np.pi)%(2*np.pi)
        co=np.cos(ang);si=np.sin(ang)
        prepared=[(z[12:16]*co+z[28:]*si/omega,z[28:]*co-omega*z[12:16]*si) for z in states]
        # An arbitrary integer number of exact free periods can be interposed.
        F,P1=prepared[0];Fminus,P2=prepared[1]
        currents=[loop(*h) for h in prepared];unique=int(np.argmax(abs(currents[0])))
        # Insert one identical, stationary receiver in each record.
        def launch(f,p):return np.r_[u,np.zeros(6),f,np.zeros(12),p]
        times=[0,.0125,.025,.05,.1,.5,1.]
        def probe(h):
            sol=solve_ivp(derivative,(0,1.),launch(*h),t_eval=times,method='DOP853',
                          rtol=tol,atol=tol/80,max_step=step)
            assert sol.success
            return np.array([right@src(z[:6]) for z in sol.y.T])
        first,second=[probe(h) for h in prepared]
        predicted=-g/6 * (right @ ((B@u)@(B@u).T) @ (P1-P2))
        assert abs(predicted)>1e-6
        pavg=(P1+P2)/2;favg=(F+Fminus)/2
        # A control reverses both stored momenta at the common section. Reversal
        # swaps the two input records and hence the sign of the later response.
        rev=probe((F,-P1))-probe((Fminus,-P2))
        div=max(float(max(abs(loop_div(c)))) for c in currents)
        En=[avg_energy(*h) for h in prepared]
        instant=[instant_energy(*h) for h in prepared]
        energy=lambda z: .5*z[16:]@z[16:]+5*z[12:16]@z[12:16]+g*z[12:16]@(src(z[:6])+src(z[6:12]))
        return {'write_duration':cut,'bracket':bracket,'cross_covariance_at_bracket':signs_bracket,
            'shared_energy_at_launch':[float(energy(h.sol(0))) for h in hist],
            'instantaneous_face_energy_max_difference_at_read':float(max(abs(instant[0]-instant[1]))),
            'common_cycle_averaged_site_energies':En[0].tolist(),'common_instantaneous_site_energies_at_read':instant[0].tolist(),
            'cycle_mean_face_energy_max_history_difference':float(max(abs(En[0]-En[1]))),'free_total_energy':[float(a.sum()) for a in En],
            'covariance_matrix_difference':float(np.linalg.norm(energy_cov(*prepared[0])-energy_cov(*prepared[1]))),
            'maximum_flux_position_mismatch_at_common_read_phase':float(max(abs(F-Fminus))),'matched_read_phase_advance':float(ang),
            'matched_flux_positions':[x.tolist() for x,p in prepared],'matched_flux_momenta':[p.tolist() for x,p in prepared],
            'common_flux_positions_on_original_axis':[float(q[0]@left) for q in prepared],
            'opposite_flux_velocities_on_written_axis':[float(q[1]@right) for q in prepared],
            'number_of_nonzero_cycle_currents_per_record_at_1e-12':int(sum(abs(currents[0])>1e-12)),
            'circulation_edges':list(zip(i.tolist(),j.tolist())),'circulation_records':[a.tolist() for a in currents],
            'max_circulation_divergence':div,'opposite_currents_max_residual':float(max(abs(currents[0]+currents[1]))),
            'maximum_current_witness':{'face_pair':[int(i[unique]),int(j[unique])],'two_signed_currents':[float(c[unique]) for c in currents]},
            'probe_times':times,'signed_probe_source_difference':(first-second).tolist(),'signed_cubic_coefficient':float(predicted),
            'leading_ratio_at_first_nonzero_time':float((first-second)[1]/(predicted*times[1]**3)),
            'momentum_reversal_max_antisymmetry_error':float(max(abs(rev+first-second))),
            'common_phase_momentum_mean_residual':float(np.linalg.norm(pavg)),
            'scope':'Writer inputs are cleared at the common event. Free storage permits any integer number of periods. Inserting a fresh identical probe is an intervention. Readout changes internal source; circulation has zero net divergence.'}
    fine=solve(2e-13,.035);coarse=solve(2e-11,.08)
    assert fine['opposite_currents_max_residual']<1e-12 and fine['covariance_matrix_difference']<1e-12
    return {'addresses':[0,11],'plane_stabilizer':fix.tolist(),'sign_intertwiners':flip.tolist(),
       'pins':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (raw_tensor,normal_tensor,registered,actions,generator)},
       'fine':fine,'refinement_write_time_difference':abs(fine['write_duration']-coarse['write_duration']),
       'refinement_max_probe_difference':float(max(abs(np.array(fine['signed_probe_source_difference'])-coarse['signed_probe_source_difference'])))}
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('chart','raw_tensor','normal_tensor','registered','actions','generator'):ap.add_argument(name,type=Path)
    print(json.dumps(run(**vars(ap.parse_args())),indent=2))
