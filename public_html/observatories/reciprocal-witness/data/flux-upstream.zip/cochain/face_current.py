#!/usr/bin/env python3
"""The 20-face strain-energy current and an exact six-component current/area map."""
import argparse
import hashlib
from itertools import combinations
from pathlib import Path
import json
import numpy as np
import sympy as sp


def run(path):
    pin=hashlib.sha256(path.read_bytes()).hexdigest()
    assert pin=="c2393278b1014c59798dc0b47c597a12f31c1c4a56d75d4872770278da98ef28"
    with np.load(path,allow_pickle=False) as arrays:
        pc,b2=arrays['PC30'],arrays['B2']
    lap=b2.T@b2
    p=pc[:,[0,1,2,5]]
    assert np.array_equal(lap@p,10*p) and sp.Matrix(p).rank()==4
    i,j=np.where(np.triu(lap<0,1))
    weights=-lap[i,j]
    assert len(i)==60 and np.all(weights==2) and np.all(np.ravel(np.diag(lap))==12)
    incidence=np.zeros((20,len(i)),dtype=int)
    incidence[i,np.arange(len(i))]=1
    incidence[j,np.arange(len(i))]=-1
    assert np.array_equal((incidence*weights)@incidence.T,lap)
    # Evaluate the exterior-square basis on the existing 60 face adjacencies.
    pairs=list(combinations(range(4),2))
    J=np.stack([p[i,k]*p[j,l]-p[i,l]*p[j,k] for k,l in pairs],axis=1)
    G=p.T@p
    g2=np.array([[G[a,c]*G[b,d]-G[a,d]*G[b,c] for c,d in pairs] for a,b in pairs])
    assert np.array_equal(18*(J.T@J),7*g2)
    assert sp.Matrix(g2).rank()==6
    assert np.all(incidence@J==0)
    # All-time local balance, including the driven case, evaluated columnwise
    # with a common denominator. Independent test matrices cover each of the
    # two states and the source by bilinearity/polarization.
    for fa in p.T:
        for vel in p.T:
            for C in p.T:
                # Set g=1 in this identity; forcing enters linearly.
                acc=-10*fa-C
                jtotal=(fa[i]-fa[j])*(vel[i]+vel[j])
                jloop=fa[i]*vel[j]-vel[i]*fa[j]
                grad=fa*vel
                assert np.array_equal(jtotal-jloop,grad[i]-grad[j])
                # Derivative of face energy 1/2 vel_i² + 1/4 sum w_ij(f_i-f_j)².
                de=vel*acc+abs(incidence)@((fa[i]-fa[j])*(vel[i]-vel[j]))
                assert np.array_equal(de+incidence@jtotal,-vel*C)
                # Difference of strain-energy and onsite allocations.
                twice_potential=abs(incidence)@((fa[i]-fa[j])**2)
                assert np.array_equal(2*twice_potential,20*fa**2-lap@(fa**2))
                dloop=fa[i]*acc[j]-acc[i]*fa[j]
                assert np.array_equal(dloop,-fa[i]*C[j]+C[i]*fa[j])
    cols=[]
    for a,b in pairs:
        ex=J[:,pairs.index((a,b))]
        cols.append({'integer_flux_basis_column_pair':[a,b],
                     'nonzero_circulation_edges':int(np.count_nonzero(ex)),
                     'squared_edge_current_norm':int(ex@ex)})
    return {'source_sha256':pin,'face_sites':len(p),'undirected_face_adjacencies':len(i),
            'face_graph_weight':2,'face_degree_unweighted':6,
            'basis_in_PC30_columns':[0,1,2,5],'face_cycle_space_dimension':60-20+1,
            'angular_area_current_rank':6,'intertwining_metric':'18 J_transpose J = 7 exterior_square_Gram',
            'divergence_of_all_six_basis_currents':'exact zero',
            'source_orbit_local_balance':'de_i/dt + div(j)_i = -g Fdot_i C_i',
            'circulating_write_law':'dj_loop,ij/dt = -g(F_i C_j-C_i F_j)',
            'time_avg_free_current':'omega[A_i B_j-A_j B_i]; gradient contribution has zero period mean',
            'circulation_examples':cols}


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('native_tensor_arrays',type=Path)
    print(json.dumps(run(ap.parse_args().native_tensor_arrays),indent=2))
