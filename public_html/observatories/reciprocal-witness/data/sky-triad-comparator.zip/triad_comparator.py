"""Enumerate every legal adjacent turn pair. Run with Python 3 and NumPy."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
PINS = {
    "native_tensor_arrays.npz": "c2393278b1014c59798dc0b47c597a12f31c1c4a56d75d4872770278da98ef28",
    "Gravity-Petrie-Probe-Receipt.json": "55680d54679b2a9f88f4379bcf1d7759d4a8bf5129e4f37d18168db9b2bbf845"
}


def check(inputs):
    for name, digest in PINS.items():
        assert sha256((inputs / name).read_bytes()).hexdigest() == digest
    with np.load(inputs / "native_tensor_arrays.npz") as arrays:
        w = arrays["W"]
        edges = arrays["canonical_edges"]
    receipt = json.loads((inputs / "Gravity-Petrie-Probe-Receipt.json").read_text())
    partner = receipt["symmetry"]["intertwiner"]
    tensor = np.zeros(partner["shape"], dtype=np.int64)
    entries = np.asarray(partner["primitive_coefficients_face_phase_edge_value"])
    tensor[tuple(entries[:, :3].T)] = entries[:, 3]
    oriented = {}
    neighbors = {}
    for index, (x, y) in enumerate(edges.tolist()):
        for origin, target, sign in [(x, y, 1), (y, x, -1)]:
            oriented[origin, target] = (index, sign)
            neighbors.setdefault(origin, []).append(target)

    def turn(x, y, z):
        i, a = oriented[x, y]
        j, b = oriented[y, z]
        return a * b * w[:, i, j]

    counts = Counter()
    example = []
    num_darts = 0
    for (v, u), (edge, orientation) in sorted(oriented.items()):
        # In both readings the analyzer is the same signed middle edge v→u.
        probe = orientation * tensor[:, :, edge]
        past = [(x, turn(x, v, u)) for x in neighbors[v]]
        future = [(y, turn(v, u, y)) for y in neighbors[u]]
        past = [(x, h) for x, h in past if np.any(h)]
        future = [(y, h) for y, h in future if np.any(h)]
        assert len(past) == len(future) == 2
        num_darts += 1
        for x, h in past:
            r = h @ probe
            for y, k in future:
                b = k @ probe
                aligned = int(h @ k)
                cross = int(r @ b)
                assert int(r @ r) == 480**2 and int(b @ b) == 420**2
                assert r[0]*b[1] - r[1]*b[0] == 0
                assert (aligned, cross) in ((1020, 201600), (-1020, -201600))
                counts[aligned, cross] += 1
                if (v, u) == (59, 17):
                    example.append(dict(previous_site=x, next_site=y,
                                        reference=r.tolist(), candidate=b.tolist(),
                                        normalized_contrast=cross//201600))
    assert num_darts == 240
    assert counts == Counter({(1020, 201600):480, (-1020, -201600):480})
    return dict(directed_edges=num_darts, lawful_windows=sum(counts.values()),
                positive_alignments=counts[1020, 201600],
                negative_alignments=counts[-1020, -201600],
                fork_59_to_17=sorted(example, key=lambda row: (row['previous_site'], row['next_site'])))


if __name__ == "__main__":
    print(json.dumps(check(ROOT / "inputs"), indent=2))
