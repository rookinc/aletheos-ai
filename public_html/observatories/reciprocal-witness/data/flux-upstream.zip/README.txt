Face and spatial inputs for the Reciprocal Witness Observatory.
The two original Python runners reproduce the archived stiffness and written four-flux records.
The native graph edge array is sorted by the original G1800 frame labels. See the
remote preparation fingerprints and the independent graph reconstruction checks.
No EHT or Planck observations appear in these finite states.
