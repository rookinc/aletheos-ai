#!/usr/bin/env python3
"""Compare the TI action gate with a separate reversible outcome register."""

import argparse
from collections import Counter, defaultdict, deque
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import runpy
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
BINARY = (0, 1)


def read(path):
    return json.loads(path.read_bytes())


def load(folder):
    expected, name = (ROOT / "INPUTS.sha256").read_text().strip().split("  ", 1)
    packed = ROOT / name
    assert sha256(packed.read_bytes()).hexdigest() == expected
    with ZipFile(packed) as archive:
        archive.extractall(folder)
    prior = folder / "TOM-PHY-027"
    sealed = (prior / "receipt.json").read_bytes()
    replay = folder / "replayed-027.json"
    subprocess.run([sys.executable, "-B", "audit.py", "--output", str(replay)], cwd=prior, check=True)
    assert replay.read_bytes() == sealed
    a27 = runpy.run_path(str(prior / "audit.py"))
    _, a23, source, sites, _, _, _ = a27["load"](folder)
    captures = read(folder / "TOM-PHY-023/captures.json")
    return a23, source, sites, captures, json.loads(sealed), sha256(sealed).hexdigest()


def pair_traces(a23, source, sites, captures, prior):
    provenance, pi, edges, group, _, atlas, _, _, _ = source
    orbits, _ = atlas
    by_history = defaultdict(dict)
    for capture in captures:
        verified = a23["verify"](capture, source)
        record = tuple(verified["record"])
        branch_bit = int(verified["relative_branch"] == "swap")
        assert branch_bit not in by_history[record]
        by_history[record][branch_bit] = capture
    outcomes = defaultdict(dict)
    for trial in prior["controlled_fork_cases"]:
        context = trial["fork"], trial["checkpoint"]
        signs = trial["test_triangle_return"], trial["reference_triangle_return"]
        assert signs not in outcomes[context]
        outcomes[context][signs] = trial

    endpoints = []
    override_controls = []
    policy_samples = []
    covariance = 0
    for fork, histories in sorted(sites.items()):
        edge_bits = {edge: k for k, edge in enumerate(sorted(histories[0]["exits"].values()))}
        assert len(edge_bits) == 2
        for history in histories:
            record = history["record"]
            checkpoint = history["checkpoint"]
            m = edge_bits[history["retained_edge"]]
            pair = by_history[record]
            tapes = {k: trace["trace"] for k, trace in pair.items()}
            assert len(tapes[0]) == len(tapes[1])
            first_tick = pair[0]["observations"][-1]["tick"]
            assert first_tick == pair[1]["observations"][-1]["tick"]
            clock_offset = prior["common_release_tick"] - tapes[0][2]["tick"]
            different = [p["tick"] + clock_offset
                         for p, q in zip(tapes[0], tapes[1], strict=True)
                         if p["ordered_G60_point"] != q["ordered_G60_point"]]
            assert different == [15, 16, 17, 18]
            assert tapes[0][-1] == tapes[1][-1] and tapes[0][-1]["tick"] + clock_offset == 19
            # The two outgoing paths even agree for each simultaneous diagonal-a representative.
            point = tuple(tapes[0][-1]["ordered_G60_point"])
            end_orbit = orbits[tapes[0][-1]["G1800_vertex"]]
            assert point in end_orbit
            endpoints.append({"fork": fork, "checkpoint": checkpoint, "ordered_G60_end": point,
                              "G1800_end": tapes[0][-1]["G1800_vertex"], "end_tick": 19,
                              "differing_full_ordered_position_ticks": different})
            for g in group.values():
                act = lambda p: tuple(g[v] for v in p["ordered_G60_point"])
                assert [p["tick"] + clock_offset
                        for p, q in zip(tapes[0], tapes[1], strict=True) if act(p) != act(q)] == different
                covariance += 1

            for signs, trial in outcomes[fork, checkpoint].items():
                test, ref = signs
                d = trial["echo"]["retained_bit"]
                assert d == int(test != ref)
                control = pair[d]
                assert control["observations"][-1]["G1800_edge"] == trial["first_edge"]
                assert control["source"] == provenance and trial["continuation_end"] == tapes[0][-1]["G1800_vertex"]
                # Independently witness the actual chosen first edge. In the intervention,
                # route the same pre-fork occurrence through the other admitted continuation.
                variants = {}
                for branch_bit in (d, 1 - d):
                    tape = tapes[branch_bit]
                    previous = tape[first_tick - 1]["ordered_G60_point"]
                    current = tape[first_tick]["ordered_G60_point"]
                    _, visible = a23["signature"](pi, previous, current, edges)
                    y_actual = edge_bits[visible]
                    pointer_before = 0
                    pointer_after = pointer_before ^ m ^ y_actual
                    no_return_pointer = pointer_before
                    assert pointer_after == branch_bit
                    variants[branch_bit] = {
                        "observed_first_edge": pair[branch_bit]["observations"][-1]["G1800_edge"],
                        "observed_exit_bit": y_actual, "pointer_from_observed_edge": pointer_after,
                        "pointer_in_forward_only_gate": no_return_pointer,
                        "mismatch_against_retained_echo": d ^ pointer_after,
                    }
                regular, forced = variants[d], variants[1 - d]
                assert regular["mismatch_against_retained_echo"] == 0
                assert forced["mismatch_against_retained_echo"] == 1
                assert regular["pointer_from_observed_edge"] != forced["pointer_from_observed_edge"]
                assert regular["pointer_in_forward_only_gate"] == forced["pointer_in_forward_only_gate"]
                assert tapes[d][:first_tick] == tapes[1 - d][:first_tick]
                policy_samples.append((fork, m, int(test == -1), int(ref == -1), d, regular["observed_exit_bit"]))
                override_controls.append({"fork": fork, "checkpoint": checkpoint, "test": test, "reference": ref,
                                          "fixed_echo": d, "fixed_history_memory": m,
                                          "normal": regular, "forced_other_exit": forced})
    assert len(endpoints) == 8 and len(override_controls) == 32 and covariance == 3840
    assert len(policy_samples) == 32
    return endpoints, override_controls, policy_samples, covariance


def information_controls(samples):
    tables = {}
    for fork in sorted({t[0] for t in samples}):
        rows = [t[1:] for t in samples if t[0] == fork]
        assert len(rows) == 8
        # y is fair on each conditioning class formed by any proper subset of (m,test,ref).
        for k in range(3):
            for ix in combinations(range(3), k):
                outputs = defaultdict(Counter)
                for row in rows:
                    outputs[tuple(row[i] for i in ix)][row[-1]] += 1
                assert all(count[0] == count[1] > 0 for count in outputs.values())
        assert len({tuple(r[:3]) for r in rows}) == len(rows) and all(
            y == m ^ test ^ ref for m, test, ref, d, y in rows)
        assert all(y == m ^ d for m, test, ref, d, y in rows)
        assert Counter((m, d) for m, test, ref, d, y in rows) == {
            (m, d): 2 for m, d in product(BINARY, repeat=2)}
        tables[fork] = {"balanced_trials": len(rows), "I_exit_history_bits": 0, "I_exit_echo_bits": 0,
                        "I_exit_joint_history_echo_bits": 1, "I_exit_any_proper_subset_history_arms_bits": 0,
                        "I_exit_joint_history_arms_bits": 1}
    return tables


def reversible_gate_control():
    def forward(state):
        d, m, y, p = state
        return d, m, y ^ d ^ m, p

    def return_write(state):
        d, m, y, p = state
        return d, m, y, p ^ m ^ y

    for state in product(BINARY, repeat=4):
        dispatched = forward(state)
        written = return_write(dispatched)
        assert dispatched[:3] == written[:3]
        assert forward(dispatched) == state and forward(return_write(written)) == state
        assert return_write(return_write(state)) == state
    return {"states_for_each_invertibility_control": 16,
            "forward_and_outcome_write_have_identical_action_outputs": True,
            "outcome_write_is_an_added_register_operation": True,
            "reciprocal_field_force_or_native_feedback_derived": False}


def undirected(u, v):
    return tuple(sorted((u, v)))


def cover_data(folder):
    p17 = folder / "TOM-PHY-017"
    cert = read(p17 / "receipt.json")
    cochains = {}
    for row in cert["fully_symmetric_double_covers"]:
        family = "Q8" if row["deck_extension_over_G15"] == "Q8" else (
            "split" if row["connected"] else "trivial")
        cochains[family, row["triangle_sign"]] = {tuple(e) for e in row["switched_native_edges_in_tree_gauge"]}
    # Recover the two comparison test cells from the same sealed source as TOM-PHY-017.
    odd_name = "Thalean-Native-Odd-Preparation-Audit.zip"
    digest, filename = next(line.split("  ", 1) for line in (p17 / "INPUTS.sha256").read_text().splitlines()
                            if line.endswith("/" + odd_name))
    payload = p17 / filename
    assert sha256(payload.read_bytes()).hexdigest() == digest
    odd_root = folder / "odd-cover-sources"
    with ZipFile(payload) as archive:
        archive.extractall(odd_root)
    odd_path, = odd_root.rglob("audit_native_odd_preparation.py")
    native_path, = odd_root.rglob("TOM-PHY-011/audit.py")
    odd = runpy.run_path(str(odd_path))
    native = runpy.run_path(str(native_path))
    p16 = folder / "TOM-PHY-016"
    a16 = runpy.run_path(str(p16 / "audit.py"))
    a17 = runpy.run_path(str(p17 / "audit.py"))
    voltage = a16["voltage_data"](native, odd)
    indices = {edge: i for i, edge in enumerate(voltage["edges"])}
    tested = a17["tested_cochains"](voltage, a16, odd, read(p16 / "receipt.json"), indices)
    for sign, mask in tested.items():
        cochains["D8_test", sign] = {e for e, i in indices.items() if (mask >> i) & 1}
    assert set(cochains) == {("Q8", 1), ("Q8", -1), ("trivial", 1), ("split", -1),
                             ("D8_test", 1), ("D8_test", -1)}
    for (_, sign), c in cochains.items():
        assert all(e in indices for e in c)
        assert sum(e in c for e in ((5, 11), (11, 20), (5, 20))) % 2 == int(sign == -1)
    return cochains


def lift_of_a(neighbours, a, cochain):
    shifts, pending = {0: 0}, deque([0])
    while pending:
        u = pending.popleft()
        for v in neighbours[u]:
            shift = shifts[u] ^ (undirected(u, v) in cochain) ^ (undirected(a[u], a[v]) in cochain)
            if v in shifts:
                assert shifts[v] == shift
            else:
                shifts[v] = shift
                pending.append(v)
    assert len(shifts) == 60
    lift = [2 * a[v] + (bit ^ shifts[v]) for v, bit in product(range(60), BINARY)]
    assert len(set(lift)) == 120 and all(lift[lift[x]] == (x ^ 1) for x in range(120))
    return lift


def product_cover(source, cochain):
    _, _, edges, _, a, (base_orbits, base_ids), _, _, _ = source
    neighbours = {u: sorted(v for x, v in edges if x == u) for u in range(60)}
    lift = lift_of_a(neighbours, a, cochain)
    adjacent = [[2 * v + (bit ^ (undirected(u, v) in cochain)) for v in neighbours[u]]
                for u, bit in product(range(60), BINARY)]
    assert all({lift[v] for v in adjacent[u]} == set(adjacent[lift[u]]) for u in range(120))

    def representative(u, v):
        return min((u, v), (lift[u], lift[v]), (u ^ 1, v ^ 1), (lift[u] ^ 1, lift[v] ^ 1))

    points = {(u, v): representative(u, v) for u, v in product(range(120), repeat=2)}
    reps = sorted(set(points.values()))
    enc = {p: i for i, p in enumerate(reps)}
    index = {point: enc[rep] for point, rep in points.items()}
    assert len(reps) == 3600 and set(Counter(points.values()).values()) == {4}
    projection = [base_ids[u // 2, v // 2] for u, v in reps]
    assert set(Counter(projection).values()) == {2}
    assert all(projection[index[u, v]] == base_ids[u // 2, v // 2] for u, v in points)
    deck = [index[u ^ 1, v] for u, v in reps]
    assert all(deck[i] != i and deck[deck[i]] == i and projection[i] == projection[deck[i]]
               for i in range(3600))
    assert all(index[u ^ 1, v] == index[u, v ^ 1] for u, v in points)

    base_adj = [{base_ids[w, v] for w in neighbours[u]} | {base_ids[u, w] for w in neighbours[v]}
                for (u, v), _ in base_orbits]
    lifted_adj = [{index[x, v] for x in adjacent[u]} | {index[u, y] for y in adjacent[v]} for u, v in reps]
    assert sum(map(len, lifted_adj)) == 28800
    assert all(len(adj) == 8 and {projection[j] for j in adj} == base_adj[projection[i]]
               and all(i in lifted_adj[j] for j in adj) for i, adj in enumerate(lifted_adj))
    seen, pending = {0}, deque([0])
    while pending:
        for v in lifted_adj[pending.popleft()] - seen:
            seen.add(v)
            pending.append(v)
    assert len(seen) == 3600
    return index, projection, deck, lifted_adj


def native_cover_records(folder, source, captures):
    _, _, _, group, a, (_, base_ids), _, _, _ = source
    cochains = cover_data(folder)
    rows = defaultdict(list)
    for c in captures:
        tick = c["observations"][-1]["tick"]
        tape = [tuple(x["ordered_G60_point"]) for x in c["trace"][tick - 1:]]
        rows[tape[0]].append(tape)
    # Registered histories at a common fork give the same two outgoing tapes.
    tapes = {point: sorted({tuple(p) for p in paths}) for point, paths in rows.items()}
    assert len(tapes) == 4 and all(len(paths) == 2 for paths in tapes.values())
    evidence = []
    controls = 0
    for key, cochain in sorted(cochains.items()):
        name, sign = key
        switch = int(name == "Q8")
        if switch:
            index, projection, deck, adj = product_cover(source, cochain)
        for point, (path0, path1) in sorted(tapes.items()):
            factor, = (i for i in (0, 1) if len({p[i] for p in path0}) > 1)
            assert all(p[1-factor] == point[1-factor] for p in (*path0, *path1))
            p0, p1 = ([p[factor] for p in path] for path in (path0, path1))
            assert path0[0] == path1[0] and path0[-1] == path1[-1]

            def parity(walk):
                return sum(undirected(u, v) in cochain for u, v in zip(walk, walk[1:])) % 2

            assert parity(p0) ^ parity(p1) == switch
            assert parity([a[v] for v in p0]) ^ parity([a[v] for v in p1]) == switch
            if name != "D8_test":
                for g in group.values():
                    assert parity([g[v] for v in p0]) ^ parity([g[v] for v in p1]) == switch
                    controls += 1
            data = {"cover": name, "triangle_sign": sign, "fork": base_ids[point],
                    "paths_in_moving_factor": [p0, p1],
                    "common_G1800_endpoint": base_ids[path0[-1]],
                    "relative_closed_loop_holonomy": (-1)**switch}
            if switch:
                for gauge in (tuple(range(60)), a):
                    for start_sheets in product(BINARY, repeat=2):
                        lifted_ends = []
                        for path in (path0, path1):
                            sheets = list(start_sheets)
                            s = index[tuple(2*gauge[v] + t for v, t in zip(path[0], sheets, strict=True))]
                            assert projection[s] == base_ids[path[0]]
                            for before, after in zip(path, path[1:]):
                                sheets[factor] ^= undirected(gauge[before[factor]], gauge[after[factor]]) in cochain
                                nxt = index[tuple(2*gauge[v] + t for v, t in zip(after, sheets, strict=True))]
                                assert nxt in adj[s] and projection[nxt] == base_ids[after]
                                s = nxt
                            lifted_ends.append(s)
                        assert deck[lifted_ends[0]] == lifted_ends[1]
                        if gauge[0] == 0 and start_sheets == (0, 0):
                            data["example_final_upstairs_ids_same_initial_sheet"] = lifted_ends
            evidence.append(data)
    assert len(evidence) == 24 and controls == 7680
    return {"tested_tapes_by_fork_and_cover": evidence, "fixed_class_covariance_checks": controls,
            "quaternionic_derived_product_cover_vertices": 3600,
            "quaternionic_derived_product_cover_edges": 14400,
            "quaternionic_reference_swap_preserves_branch_readability_for_both_echo_polarities": True,
            "coupling_that_places_actual_action_on_lifted_carrier_supplied_by_archive": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "receipt.json")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="tom-phy-028-") as temp:
        folder = Path(temp)
        a23, source, sites, captures, prior, prior_sha = load(folder)
        ends, interventions, samples, covariance = pair_traces(a23, source, sites, captures, prior)
        information = information_controls(samples)
        gates = reversible_gate_control()
        cover = native_cover_records(folder, source, captures)
    a23["write"](args.output, {
        "audit": "TOM-PHY-028", "upstream_027_receipt_sha256": prior_sha,
        "endpoint_blindness_pairs": ends, "native_relabel_checks_of_branch_readout_window": covariance,
        "independent_observed_edge_write_controls": interventions, "information_exact_counts": information,
        "reversible_gates": gates, "native_lifted_branch_record": cover,
        "scope": "controlled receipt and exact lifted route separation; no mechanical return law or historical assignment",
    })


if __name__ == "__main__":
    main()
