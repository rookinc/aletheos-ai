# Reciprocal Witness Observatory

## Reproduce an encounter

The kit contains the browser's native fixtures, independent rational and numerical solvers, the measured Planck coefficients, the original compact source subsets and SHA-256 manifests. Unzip it, enter the directory, and run the checks. Scientific replay runs offline. Use Node 22 or later, Python 3.11 or later, NumPy, SciPy and SymPy. Rendering the optional Planck image also uses Pillow and SciPy 1.15 or later.

```sh
python3 tests/run-science.py
node tests/results.mjs > my-benchmarks.json
```

[Download the science replay kit](https://aletheos.ai/observatories/reciprocal-witness/data/replay-kit.zip) · [Exact and numerical benchmark receipts](./data/benchmarks.json) · [Input and engine checksums](./data/replay-sha256.json)

| Experiment | Independent check |
| --- | --- |
| Lifted routes and counterfactual | Python fractions on 3,600 sites, eight route/pair/readout settings, each recorded port and source, 16- and 112-edge balances |
| Native echo selector | Eight fixed-fork preparations covering both incoming checkpoints and all test/reference signs |
| Current and stored circulation | Every selected face edge, both sign controls, energy continuity, analytic positive and negative traffic, complete period, three receiver-clearing cuts |
| Exterior graph wave | Full 1,800-site SciPy exponential against the 484-class browser calculation, all 7,200 spatial edges and quadrature refinement |
| Sky and previous triad | 72 optical preparations, 960 lawful windows on 240 directed edges, both previous references and all candidate overlaps |
| Synthetic two-heart fields | Independent normal modes, omitted-beat decomposition, deterministic matching of both drive arrays, checkpoint locality and one-step return |

The original TOM-PHY-029 and TOM-PHY-027 runners were also rerun against their archival input chains. Both produced byte-identical sealed receipts. Their scripts and receipts are in the public subset. Regenerating the historical 029 cover extraction requires the original TOM-PHY-029 archive. The distributed fixture and fraction check reproduce the exhibit independently.

## Source versions

- [TOM runner and receipt subset](./data/paired-original-receipts.zip) · [paired-cover provenance](./data/paired-provenance.json)
- [Face-wave writer and 7,200-edge subset](./data/flux-upstream.zip) · [face and exterior provenance](./data/flux-provenance.json)
- [Original finite triad analyzer](./data/sky-triad-comparator.zip) · [Planck reduction and observer provenance](./data/sky-provenance.json)
- [Synthetic field law](./heart.js) · [independent two-heart replay](./tests/heart-check.mjs)

The duplicate-run identifier is a deterministic, short FNV-1a fingerprint for visual comparison. The exported JSON contains the actual preparation, clock, numbers and intervention. SHA-256 in the manifests identifies source bytes. Camera and display geometry do not enter either solver or receipt.

